# LLF — Editable String Table

LLF ("Localization List Format") is a plain UTF-8 text alternative to the binary CSF
string table. It looks like YAML and is best viewed with YAML syntax highlighting,
but it is **not** YAML and is not parsed by a YAML parser.

Original format by **小星星 / Uranusian**, published by **Mr.L** on the RA2DIY forum
([thread 24441](https://bbs.ra2diy.com/forum.php?mod=viewthread&tid=24441), 2024-09-17)
as the closed-source `EditableCSF.dll`. This is an independent reimplementation inside
Phobos; divergences are listed at the end.

## Why

- Editable in any text editor — save and run, no CSF tool round-trip.
- Any character UTF-8 can represent.
- Diffable and mergeable, so string tables work properly under version control.

---

## Loading

Files are named `stringtable00.llf` through `stringtable99.llf`. For each index the
`.csf` is loaded first and the `.llf` second, so **LLF always wins** on a label that
exists in both.

Loading goes through `CCFileClass`, so a `.llf` works the same loose in the game
directory or packed inside a MIX.

```cpp
CSFLoader::LoadAdditionalStringTables();   // scans 00..99, csf then llf
CSFLoader::ParseLLFFile("mystrings.llf");  // or load one directly
```

`LoadAdditionalCSF()` also dispatches on the extension, and after parsing a `.csf` it
looks for the `.llf` sibling of the same name — so existing call sites get LLF
priority without being changed.

---

## Syntax

### Entries

The **first** `": "` (colon followed by a space) on a line splits label from value.
Everything before it is the label, everything after is the value.

```yaml
Name:MTNK: Grizzly Battle Tank
```

Later colons are just text, and a colon with no space after it is just text:

```yaml
TEST:Colon: Ratio: 3: 1        →  "Ratio: 3: 1"
TEST:ColonNoSpace: 12:30 PM    →  "12:30 PM"
```

Labels are case-insensitive on lookup and have no length limit. Leading spaces in the
value are kept verbatim; trailing whitespace on every line is stripped.

A label with nothing after the colon yields an empty string:

```yaml
TEST:Empty:
```

### Comments

`#` starts a comment when it is at the start of a line, or when the character before
it is a space or tab. Anywhere else it is a literal `#`.

```yaml
TEST:CommentTail: visible # this part is cut     →  "visible"
TEST:HashLiteral: Player#1 wins                  →  "Player#1 wins"
TEST:HashEscape: Player \#1 wins                 →  "Player #1 wins"
# a whole-line comment
   # an indented comment — skipped entirely, does not end the entry above
```

`\#` producing a literal `#` is an extension, not in the original format. Turn it off
with `CSFLoader::LLFAllowHashEscape = false`.

### Multi-line values

A line beginning with **two spaces** continues the previous entry. Continuation lines
are joined with a newline, which is what the game renders as a line break.

The `>-` marker after `": "` announces a multi-line value. The converter script emits
it for every multi-line subtitle. It is optional — the two-space rule is what actually
drives continuation.

```yaml
TEST:Block: >-
  First subtitle line
  Second subtitle line
  # a comment here adds no blank line
  Third subtitle line
```

→ `"First subtitle line\nSecond subtitle line\nThird subtitle line"`

A whitespace-only continuation line produces a blank line:

```yaml
TEST:BlockWithBlank: >-
  Paragraph one
  
  Paragraph two
```

→ `"Paragraph one\n\nParagraph two"`

Continuation works without the marker too:

```yaml
TEST:PlainMulti: opening line
  continued line
```

→ `"opening line\ncontinued line"`

There is no `\n` escape — use a continuation line.

### Ending an entry

An entry ends at a blank line, at the next label line, or at end of file. A blank
separator line is conventional but not required:

```yaml
TEST:AdjacentA: first
TEST:AdjacentB: second
```

### Duplicates

The last definition in the file wins, and the override is written to `debug.log`. The
original DLL forbade duplicates within one file (it could prevent the game starting);
this implementation handles them.

### Encoding

UTF-8. A byte-order mark is skipped if present. LF, CRLF and lone CR all work.
Characters outside the BMP (emoji, rare CJK) become UTF-16 surrogate pairs — whether
they *render* depends on the game font, not the parser. Malformed byte sequences
decode to U+FFFD rather than failing the file.

---

## Full example

```yaml
# mymod strings

Name:MTNK: Grizzly Battle Tank
Name:HTNK: Apocalypse Tank          # heavy

TXT:Briefing: >-
  Commander, the enemy has fortified the ridge.
  Take the northern bridge before dawn.

TXT:Empty:
TXT:Unicode: 中文 — Ünïcödé — русский
```

---

## Tunables

Runtime flags on `CSFLoader`, all safe to leave at their defaults:

| Flag | Default | Effect |
|---|---|---|
| `LLFFoldPlainContinuations` | `false` | `true` joins continuations of a *non*-`>-` entry with a space instead of a newline |
| `LLFTrimContinuationIndent` | `true` | strips the whole leading whitespace run of a continuation line, so generator indent width does not leak into the string |
| `LLFAllowHashEscape` | `true` | `\#` emits a literal `#` |

---

## Differences from the original `EditableCSF.dll`

| | Original | This implementation |
|---|---|---|
| Duplicate labels in one file | forbidden (fixed in 0.4) | last wins, logged |
| Label length | crashed above 32 chars (fixed in 0.4) | unlimited |
| `ra2md.llf` | deliberately not supported | supported as an extension |
| Storage | writes into `StringTable::` arrays | own `LabelMap`, engine arrays unused |
| Dependency | requires Ares | none, part of Phobos |

Details not stated in the original post and therefore inferred here: continuations
join with `\n` (not folded to spaces), trailing newlines are stripped, `>`/`|`/`|-`
are accepted alongside `>-`, and a bare `Label:` yields an empty value.

**Do not run this alongside `EditableCSF.dll`** — both take over string table loading.
