#pragma once
#include <TeamClass.h>

#include <Utilities/Container.h>
#include <Utilities/Iterator.h>
#include <Utilities/MapPathCellElement.h>
#include <Utilities/PhobosFixedString.h>

#include <TeamTypeClass.h>

class TechnoTypeClass;
class HouseClass;
class FootClass;
class SuperClass;
class AITriggerTypeClass;
class TeamExtData final : public AbstractExtended
{
public:
	using base_type = TeamClass;
	static COMPILETIMEEVAL const char* ClassName = "TeamExtData";
	static COMPILETIMEEVAL const char* BaseClassName = "TeamClass";
	static COMPILETIMEEVAL DWORD Canary = 0x9C9C9505;

public:

#pragma region ClassMembers
	PhobosFixedString<0x18> Name {};
	int WaitNoTargetAttempts { 0 };
	double NextSuccessWeightAward { 0.0 };
	int IdxSelectedObjectFromAIList { -1 };
	double CloseEnough { -1.0 };
	int Countdown_RegroupAtLeader { -1 };
	int MoveMissionEndMode { 0 };
	int WaitNoTargetCounter { 0 };
	CDTimerClass WaitNoTargetTimer {};
	CDTimerClass ForceJump_Countdown {};
	int ForceJump_InitialCountdown { -1 };
	bool ForceJump_RepeatMode { false };
	FootClass* TeamLeader { nullptr };
	SuperClass* LastFoundSW { nullptr };
	bool ConditionalJump_Evaluation { false };
	int ConditionalJump_ComparatorMode { 3 };
	int ConditionalJump_ComparatorValue { 1 };
	int ConditionalJump_Counter { 0 };
	int ConditionalJump_Index { -1000000 };
	bool AbortActionAfterKilling { false };
	bool ConditionalJump_EnabledKillsCount { false };
	bool ConditionalJump_ResetVariablesIfJump { false };
	int TriggersSideIdx { -1 };
	int TriggersHouseIdx { -1 };
	int AngerNodeModifier { 5000 };
	bool OnlyTargetHouseEnemy { false };
	int OnlyTargetHouseEnemyMode { -1 };
	ScriptTypeClass* PreviousScript { nullptr };
	std::vector<BuildingClass*> BridgeRepairHuts {};
#pragma endregion

public:
	TeamExtData(TeamClass* pObj) : AbstractExtended(pObj)
	{
		this->Name = pObj->Type->ID;
		this->AbsType = TeamClass::AbsID;
	}

	TeamExtData() = default;

	virtual ~TeamExtData() = default;

	virtual void InvalidatePointer(AbstractClass* ptr, bool bRemoved, AbstractType type) override;

	virtual void LoadFromStream(PhobosStreamReader& Stm) override
	{
		this->AbstractExtended::Internal_LoadFromStream(Stm);
		this->Serialize(Stm);
	}

	virtual void SaveToStream(PhobosStreamWriter& Stm)
	{
		const_cast<TeamExtData*>(this)->AbstractExtended::Internal_SaveToStream(Stm);
		const_cast<TeamExtData*>(this)->Serialize(Stm);
	}

	virtual AbstractType WhatIam() const { return base_type::AbsID; }
	virtual int GetSize() const { return sizeof(*this); };

	virtual void CalculateCRC(CRCEngine& crc) const { }

	TeamClass* This() const { return reinterpret_cast<TeamClass*>(this->AttachedToObject); }
	const TeamClass* This_Const() const { return reinterpret_cast<const TeamClass*>(this->AttachedToObject); }

public:

	static bool HouseOwns(AITriggerTypeClass* pThis, HouseClass* pHouse, bool allies, const Iterator<TechnoTypeClass*>& list);
	static bool HouseOwnsAll(AITriggerTypeClass* pThis, HouseClass* pHouse, const Iterator<TechnoTypeClass*>& list);
	static bool EnemyOwns(AITriggerTypeClass* pThis, HouseClass* pHouse, HouseClass* pEnemy, bool onlySelectedEnemy, const Iterator<TechnoTypeClass*>& list);
	static bool EnemyOwnsAll(AITriggerTypeClass* pThis, HouseClass* pHouse, HouseClass* pEnemy, const Iterator<TechnoTypeClass*>& list);
	static bool NeutralOwns(AITriggerTypeClass* pThis, const Iterator<TechnoTypeClass*>& list);
	static bool NeutralOwnsAll(AITriggerTypeClass* pThis, const Iterator<TechnoTypeClass*>& list);
	static bool NOINLINE GroupAllowed(TechnoTypeClass* pThis, TechnoTypeClass* pThat);

	static bool IsEligible(TechnoClass* pGoing, TechnoTypeClass* reinfocement);
	static bool IsEligible(TechnoTypeClass* pGoing, TechnoTypeClass* reinfocement);

	static int GetSafeFriendlyDistance(TeamTypeClass* pTeam, int arg);
	static int GetSafeDistance(TeamTypeClass* pTeam, int arg);

	static void GetAIChronoshiftSupers(HouseClass* pThis, SuperClass*& pSuperCSphere, SuperClass*& pSuperCWarp);
	static bool IsCloseToCenter(FootClass* pMember, AbstractClass* pCenterCell, int stray);
private:
	template <typename T>
	void Serialize(T& Stm);
};

class TeamExtContainer final : public Container<TeamExtData>
	, public ContainerSaveLoad<TeamExtContainer, TeamExtData>
{
public:
	static COMPILETIMEEVAL const char* ClassName = "TeamExtContainer";

public:
	static TeamExtContainer Instance;

	virtual bool SaveGlobal(PhobosStreamWriter& stm) { return true; }
	virtual bool LoadGlobal(PhobosStreamReader& stm) { return true; }
};

class NOVTABLE FakeTeamClass : public TeamClass
{
public:

	HRESULT __stdcall __Load(IStream* pStm);
	HRESULT __stdcall __Save(IStream* pStm, BOOL fClearDirty);

	void _Detach(AbstractClass* target, bool all);

	void _AI();
	bool _CoordinateRegroup();
	void _TeamClass_6EA080();
	void _CoordinateMove();
	void _AssignMissionTarget(AbstractClass* new_target);
	bool _Recalculate();
	void _Regroup();
	void _Calc_Center(AbstractClass** outCell, FootClass** outClosestMember);
	bool _Lagging_Units();
	bool _Add(FootClass* obj);
	bool _Add2(FootClass* obj, bool ignoreQuantity);
	bool _Can_Add(FootClass* attacker, int* entry, bool ignoreQuantity);
	bool _Remove(FootClass* obj, int typeindex, bool enterIdleMode);
	bool _Recruit(int a3);
	void _Took_Damage(FootClass* a2, DamageState result, ObjectClass* source);
	void _Coordinate_Attack();
	bool _Coordinate_Conscript(FootClass* a2);
	bool _Is_A_Member(FootClass* member);
	bool _Is_Leaving_Map();
	bool _Has_Entered_Map();
	bool _has_aircraft();
	void _Scan_Limit();
	FootClass* _Fetch_A_Leader();
	void _GetTaskForceMissingMemberTypes(std::vector<TechnoTypeClass*>& missings);
	void _Flash_For(int a2);
	int _Get_Stray();
	bool _Does_Any_Member_Have_Ammo();

	void ExecuteTMissions(bool missionChanged);

	static void _fastcall _Suspend_Teams(int priority, HouseClass* house);
	//

	void _Coordinate_Do(ScriptActionNode* pNode ,CellStruct unused);

	void _TMission_Unload(ScriptActionNode* nNode, bool arg3);
	void _TMission_Load(ScriptActionNode* nNode, bool arg3);
	void _TMission_Deploy(ScriptActionNode* nNode, bool arg3);
	void _TMission_Scout(ScriptActionNode* nNode, bool arg3);
	void _TMission_Move_To_Own_Building(ScriptActionNode* nNode, bool arg3);
	void _TMission_Attack_Enemy_Building(ScriptActionNode* nNode, bool arg3);
	void _TMission_Chrono_prep_for_abwp(ScriptActionNode* nNode, bool arg3);
	void _TMission_Chrono_prep_for_aq(ScriptActionNode* nNode, bool arg3);
	void _TMission_Play_Animation(ScriptActionNode* nNode, bool arg3);
	void _TMission_Iron_Curtain_Me(ScriptActionNode* nNode, bool arg3);
	void _TMission_Guard(ScriptActionNode* nNode, bool arg3);
	void _TMission_GatherAtBase(ScriptActionNode* nNode, bool arg3);
	void _TMission_GatherAtEnemy(ScriptActionNode* nNode, bool arg3);
	void _TMission_ChangeHouse(ScriptActionNode* nNode, bool arg3);
	void _TMission_Enter_Grinder(ScriptActionNode* nNode, bool arg3);
	void _TMission_Enter_Bio_Reactor(ScriptActionNode* nNode, bool arg3);
	void _TMission_Occupy_Battle_Bunker(ScriptActionNode* nNode, bool arg3);
	void _TMission_Occupy_Tank_Bunker(ScriptActionNode* nNode, bool arg3);
	void _TMission_Attack(ScriptActionNode* nNode, bool arg3);
	void _TMission_Attack_Waypoint(ScriptActionNode* nNode, bool arg3);
	void _TMission_Move_To_Cell(ScriptActionNode* nNode, bool arg3);
	void _TMission_Loop(ScriptActionNode* nNode, bool arg3);
	void _TMission_Player_wins(ScriptActionNode* nNode, bool arg3);
	void _TMission_Player_loses(ScriptActionNode* nNode, bool arg3);
	void _TMission_Talk_bubble(ScriptActionNode* nNode, bool arg3);

	//

	TeamExtData* _GetExtData() {
		return *reinterpret_cast<TeamExtData**>(((DWORD)this) + AbstractExtOffset);
	}

};

static_assert(sizeof(FakeTeamClass) == sizeof(TeamClass), "Invalid Size !");